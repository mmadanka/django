default_app_config = 'fundraising.apps.FundraisingConfig'
